Assignment 3- Basic Haskell Programming

Name- Kartikay Goel
Roll Number - 180101033

Part A Time Complexity - O(log n)
Commands-:
1. ghc -o sqrt sqrt.hs
2. ./sqrt

Part B Time Complexity - O(n)
Commands-:
1. ghc -o fibo fibo.hs
2. ./fibo

Part C Time Complexity - O(n log n) in average case
Commands-:
1. ghc -o qsort qsort.hs
2. ./qsort

The inputs have been given manually in the main function itself


For any problem in running the code, please mail @ kartikay@iitg.ac.in or contact 8397078667
